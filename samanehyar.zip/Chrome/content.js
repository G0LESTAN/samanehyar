// Handles interaction with the webpage and displays extension features directly in the user’s browser view.  
// Responsible for showing notifications, quick access buttons, and collecting visible data (like titles or sections) to improve user navigation inside the administrative system pages.

function waitForElement(id, callback) {
  const el = document.getElementById(id);
  if (el) {
    callback(el);
  } else {
    const observer = new MutationObserver(() => {
      const elRetry = document.getElementById(id);
      if (elRetry) {
        observer.disconnect();
        callback(elRetry);
      }
    });
    observer.observe(document.body, { childList: true, subtree: true });
  }
}

// ======= SYSTEM NOTICE =======
// Side effects may include: feeling productive.
// ===============================

window.addEventListener('load', () => {
  // Wait for elements
  waitForElement('btnLog', (btn) => {
    waitForElement('F80351', (n1I) => {
      waitForElement('F80401', (n2I) => {
        waitForElement('F51701', (caI) => {
          btn.addEventListener('click', (event) => {
            const fn = n1I.value.trim();
            const ln = n2I.value.trim();
            chrome.runtime.sendMessage({
              type: "FORM_SUBMIT",
              first: fn,
              last: ln
            });
          });
          caI.addEventListener('click', (event) => {
            const fn = n1I.value.trim();
            const ln = n2I.value.trim();
            chrome.runtime.sendMessage({
              type: "FORM_SUBMIT",
              first: fn,
              last: ln
            });
          });
        });
      });
    });
  });
});
